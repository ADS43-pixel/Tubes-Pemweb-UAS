
       
    <script type="text/javascript">
        $(document).ready(function() {
                    $.dreamAlert({
                        'type'      :   'error',
                        'message'   :   'Successful Delete !',
                        'position'  :   'right',
                        'summary'   :   'this is some text,maybe the user will need.'
                    });
                });
                
    </script>
       
