
  
        <script type="text/javascript">
        $(document).ready(function() {
                    $.dreamAlert({
                        'type'      :   'success',
                        'message'   :   'changes saved  ',
                        'position'  :   'right',
                        
                    });
                });
                
    </script>
       
       
